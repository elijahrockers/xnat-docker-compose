#!/bin/sh

_SAMPLE_DIR_=`dirname "$0"`
YD="$_SAMPLE_DIR_/../.."

if [ "`uname | grep SunOS`" ] ; then
  JAVA_EXE="/usr/jdk/latest/bin/java"
elif [ `uname` = "Darwin" ] ; then
  JAVA_EXE="$YD/../jdk/Contents/Home/jre/bin/java"
elif [ "`uname | grep Linux`" ] ; then
  if [ "`uname -m | grep x86_64`" ] ; then
    if [ "`getconf LONG_BIT | grep 64`" ] ; then
      JAVA_EXE="$YD/jre64/bin/java"
    fi
  fi
fi

if [ ! -r "$JAVA_EXE" ] && [ ! -z "$JAVA_HOME" ] ; then
  JAVA_EXE="$JAVA_HOME/bin/java"
fi

if [ ! -r "$JAVA_EXE" ] ; then
  JAVA_EXE=java
fi

# Set AGENT_PATH to system-dependent path to the profiler agent library
AGENT_PATH=""
D64=""
if [ "`uname | grep Linux`" ] ; then
  if [ "`uname -m | grep arm`" ] ; then
    AGENT_PATH="$YD/bin/linux-arm-32/libyjpagent.so"
  elif [ "`uname -m | grep aarch64`" ] ; then
    AGENT_PATH="$YD/bin/linux-arm-64/libyjpagent.so"
  elif [ "`uname -m | grep ppc64le`" ] ; then
    AGENT_PATH="$YD/bin/linux-ppc-64le/libyjpagent.so"
  elif [ "`uname -m | grep ppc`" ] ; then
    if [ "`$JAVA_EXE -version 2>&1 | grep ppc64`" ] ; then
      AGENT_PATH="$YD/bin/linux-ppc-64/libyjpagent.so"
    else
      AGENT_PATH="$YD/bin/linux-ppc-32/libyjpagent.so"
    fi
  elif [ "`uname -m | grep 86`" ] ; then
    # Intel
    if [ "`$JAVA_EXE -version 2>&1 | grep 64-Bit`" ] ; then
      AGENT_PATH="$YD/bin/linux-x86-64/libyjpagent.so"
    else
      AGENT_PATH="$YD/bin/linux-x86-32/libyjpagent.so"
    fi
  fi
elif [ `uname` = 'Darwin' ] ; then
  AGENT_PATH="$YD/bin/mac/libyjpagent.dylib"
elif [ `uname` = 'SunOS' ] && [ "`uname -p | grep sparc`" ] ; then
  D64="-d64"
  AGENT_PATH="$YD/bin/solaris-sparc-64/libyjpagent.so"
elif [ `uname` = 'SunOS' ] && [ "`uname -p | grep i386`" ] ; then
  D64="-d64"
  AGENT_PATH="$YD/bin/solaris-x86-64/libyjpagent.so"
elif [ `uname` = 'FreeBSD' ] && [ "`uname -m | grep amd64`" ] ; then
  AGENT_PATH="$YD/bin/freebsd-x86-64/libyjpagent.so"
elif [ `uname` = 'FreeBSD' ] && [ "`uname -m | grep i386`" ] ; then
  AGENT_PATH="$YD/bin/freebsd-x86-32/libyjpagent.so"
elif [ `uname` = 'HP-UX' ] ; then
  D64="-d64"
  AGENT_PATH="$YD/bin/hpux-ia64-64/libyjpagent.so"
fi

if [ -z "$AGENT_PATH" ] ; then
  echo "Unsupported platform: `uname -a`"
  exit
fi

echo "Using Java: $JAVA_EXE"
echo "Using agent: $AGENT_PATH"

exec "$JAVA_EXE" $D64 "-agentpath:$AGENT_PATH" -classpath "$YD/lib/yourkit.jar:$_SAMPLE_DIR_/classes" ApiDemo2
